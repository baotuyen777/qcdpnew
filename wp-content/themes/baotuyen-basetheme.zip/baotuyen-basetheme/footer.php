
</div><!-- container -->

<footer id="bg_footer">
    <div class="container">
        <h3 >Công ty TNHH quảng cáo và phát triển công nghệ Đức Phát</h3>
        <div class="info-office">
            <div>Địa chỉ: 278 KIm Giang - Thanh Xuân - Hà Nội </div>
            <div>
                Tel: 04. 22.11.99.66 - Hotline: 094 81 123 18</div>
            <div>
                Email: quangcaoducphat@gmail.com
            </div>
        </div>
        <?php // echo get_field('footer', PAGE_HOME) ?>
        <a rel="nofollow" href="https://www.facebook.com/baotuyen666" id="desa">DavidBui</a>
    </div>
</footer>

<?php wp_footer(); ?>

<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/js/jquery.orbit-1.2.3.min.js"></script>
<script src="<?php echo get_template_directory_uri() ?>/js/customs.js"></script>
</body>

</html>