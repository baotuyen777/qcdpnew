<?php
/**
 * Template Name: Contact
 */
get_header(); ?>
<div id="right">
    <div class="box_top"><a href="http://quangcaoquanson.com/thi-cong-bien-hieu-quang-cao-dai-ly-cho-cac-thuong-hieu" title="Thi công biển hiệu quảng cáo đại lý cho các thương hiệu">Thi công biển hiệu quảng cáo đại lý cho các thương hiệu</a>
    </div>
    <div id="owl-demo14" class="owl-carousel">
        <div class="itemchay1">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/lam-bien-quang-cao-cho-cac-dai-ly-nha-phan-phoi" title="Làm biển quảng cáo cho các đại lý nhà phân phối"><img src="upload/files/lam bien quang cao/20130605164413YjN52sAh.jpg" title="Làm biển quảng cáo cho các đại lý nhà phân phối" alt="Làm biển quảng cáo cho các đại lý nhà phân phối" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/lam-bien-quang-cao-cho-cac-dai-ly-nha-phan-phoi">Làm biển quảng cáo cho các đại lý nhà phân phối</a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/thi-cong-bien-quang-cao-quanh-hang-rao-xay-dung" title="Thi công biển quảng cáo quanh hàng rào xây dựng"><img src="upload/files/010.jpg" title="Thi công biển quảng cáo quanh hàng rào xây dựng" alt="Thi công biển quảng cáo quanh hàng rào xây dựng" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/thi-cong-bien-quang-cao-quanh-hang-rao-xay-dung">Thi công biển quảng cáo quanh hàng rào xây dựng</a>
            </div>
        </div>
        <div class="itemchay2">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/lam-bien-dong-bien-inox-cong-ty-phong-ban-chu-noi-inox" title="Làm biển đồng, biển inox công ty phòng ban Chữ nổi inox"><img src="upload/files/lam bien quang cao/Bien inox mica trong.jpg" title="Làm biển đồng, biển inox công ty phòng ban Chữ nổi inox" alt="Làm biển đồng, biển inox công ty phòng ban Chữ nổi inox" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/lam-bien-dong-bien-inox-cong-ty-phong-ban-chu-noi-inox">Làm biển đồng, biển inox công ty phòng ban Chữ nổi inox</a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/lam-bien-hieu-quang-cao" title="Làm biển hiệu quảng cáo"><img src="upload/files/lam bien quang cao/bang-hieu-alu-0108a2.jpg" title="Làm biển hiệu quảng cáo" alt="Làm biển hiệu quảng cáo" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/lam-bien-hieu-quang-cao">Làm biển hiệu quảng cáo</a>
            </div>
        </div>
        <div class="itemchay4">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/thi-cong-bang-hieu-quang-cao" title="Thi công bảng hiệu quảng cáo"><img src="upload/files/lam bien quang cao/images.jpg" title="Thi công bảng hiệu quảng cáo" alt="Thi công bảng hiệu quảng cáo" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/thi-cong-bang-hieu-quang-cao">Thi công bảng hiệu quảng cáo</a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/thi-cong-quang-cao-den-led dep" title="Thi Công Quảng Cáo Đèn Led Đẹp"><img src="upload/files/bang-chay-chu1.jpg" title="Thi Công Quảng Cáo Đèn Led Đẹp" alt="Thi Công Quảng Cáo Đèn Led Đẹp" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/thi-cong-quang-cao-den-led dep">Thi Công Quảng Cáo Đèn Led Đẹp</a>
            </div>
        </div>
        <div class="itemchay6">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/thi-cong-bang-hieu-hop-den" title="Thi công bảng hiệu hộp đèn"><img src="upload/files/lam bien quang cao/bien-bat-hiflex.jpg" title="Thi công bảng hiệu hộp đèn" alt="Thi công bảng hiệu hộp đèn" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/thi-cong-bang-hieu-hop-den">Thi công bảng hiệu hộp đèn</a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/thi-cong-bang-hieu-nhom-alu" title="Thi công bảng hiệu nhôm Alu"><img src="upload/files/lam bien quang cao/tu-van-lam-bien-quang-cao-theo-nhu-cau1.jpg" title="Thi công bảng hiệu nhôm Alu" alt="Thi công bảng hiệu nhôm Alu" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/thi-cong-bang-hieu-nhom-alu">Thi công bảng hiệu nhôm Alu</a>
            </div>
        </div>
        <div class="itemchay8">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/bang-hieu-hop-den" title="Bảng hiệu, hộp đèn"><img src="upload/files/lam bien quang cao/bang_hieu1-500x375.jpg" title="Bảng hiệu, hộp đèn" alt="Bảng hiệu, hộp đèn" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/bang-hieu-hop-den">Bảng hiệu, hộp đèn</a>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function () {
            $("#owl-demo14").owlCarousel({
                navigation: true,
                navigationText: ["<", ">"],
                autoPlay: 5000,
                items: 4,
                itemsDesktop: [1199, 3],
                itemsDesktopSmall: [979, 3]
            });

        });
    </script>

    <div class="box_top"><a href="http://quangcaoquanson.com/cac-cong-trinh-da-hoan-thanh-2016-2017" title="CÁC CÔNG TRÌNH ĐÃ HOÀN THÀNH 2016 - 2017">CÁC CÔNG TRÌNH ĐÃ HOÀN THÀNH 2016 - 2017</a>
    </div>
    <div id="owl-demo16" class="owl-carousel">
        <div class="itemchay1">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/poter-kinh-dep" title="Poter kính đẹp "><img src="upload/files/poter kinh 3.jpg" title="Poter kính đẹp " alt="Poter kính đẹp " />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/poter-kinh-dep">Poter kính đẹp </a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/bien-vay-hop-den-dep" title="Biển vẫy hộp đèn đẹp"><img src="upload/files/biển vẫy.jpg" title="Biển vẫy hộp đèn đẹp" alt="Biển vẫy hộp đèn đẹp" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/bien-vay-hop-den-dep">Biển vẫy hộp đèn đẹp</a>
            </div>
        </div>
        <div class="itemchay2">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/bien-chi-dan-tai-toa-nha-nts-noi-bai" title="Biển chỉ dẫn tại tòa nhà NTS Nội Bài"><img src="upload/files/nts.jpg" title="Biển chỉ dẫn tại tòa nhà NTS Nội Bài" alt="Biển chỉ dẫn tại tòa nhà NTS Nội Bài" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/bien-chi-dan-tai-toa-nha-nts-noi-bai">Biển chỉ dẫn tại tòa nhà NTS Nội Bài</a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/bien-trung-tam-summer-school" title="Biển trung tâm summer school"><img src="upload/files/bien tam op va den led matrix.jpg" title="Biển trung tâm summer school" alt="Biển trung tâm summer school" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/bien-trung-tam-summer-school">Biển trung tâm summer school</a>
            </div>
        </div>
        <div class="itemchay4">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/lam-chu-noi-den-led" title="Làm chữ nổi đèn led "><img src="upload/files/bo chu the coffe house.jpg" title="Làm chữ nổi đèn led " alt="Làm chữ nổi đèn led " />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/lam-chu-noi-den-led">Làm chữ nổi đèn led </a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/chu-noi-den-led-trong-chu" title="Chữ nổi đèn led trong chữ"><img src="upload/files/tuoi song.jpg" title="Chữ nổi đèn led trong chữ" alt="Chữ nổi đèn led trong chữ" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/chu-noi-den-led-trong-chu">Chữ nổi đèn led trong chữ</a>
            </div>
        </div>
        <div class="itemchay6">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/lam-bien-chu-noi" title="Làm biển chữ nổi "><img src="upload/files/bien-quang-cao-mica-1.jpg" title="Làm biển chữ nổi " alt="Làm biển chữ nổi " />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/lam-bien-chu-noi">Làm biển chữ nổi </a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/thiet-ke-thi-cong-bien-led" title="Thiết Kế Thi công biển Led"><img src="upload/files/unnamed.gif" title="Thiết Kế Thi công biển Led" alt="Thiết Kế Thi công biển Led" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/thiet-ke-thi-cong-bien-led">Thiết Kế Thi công biển Led</a>
            </div>
        </div>
        <div class="itemchay8">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/lam-bien-ten-chuc-danh-bien-an-mon-chu-dong-inox" title="Làm biển tên chức danh, biển ăn mòn, chữ Đồng, Inox"><img src="upload/files/huy hie.jpg" title="Làm biển tên chức danh, biển ăn mòn, chữ Đồng, Inox" alt="Làm biển tên chức danh, biển ăn mòn, chữ Đồng, Inox" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/lam-bien-ten-chuc-danh-bien-an-mon-chu-dong-inox">Làm biển tên chức danh, biển ăn mòn, chữ Đồng, Inox</a>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function () {
            $("#owl-demo16").owlCarousel({
                navigation: true,
                navigationText: ["<", ">"],
                autoPlay: 5000,
                items: 4,
                itemsDesktop: [1199, 3],
                itemsDesktopSmall: [979, 3]
            });

        });
    </script>

    <div class="box_top"><a href="http://quangcaoquanson.com/thi-cong-bien-quang-cao-cua-hang-showroom-cong-ty" title="Thi công biển quảng cáo cửa hàng, showroom, công ty">Thi công biển quảng cáo cửa hàng, showroom, công ty</a>
    </div>
    <div id="owl-demo18" class="owl-carousel">
        <div class="itemchay1">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/thi-cong-bien-quang-cao-shop-thoi-trang-–-my-pham" title="Thi công biển quảng cáo shop thời trang – mỹ phẩm "><img src="upload/files/showroom/bien-shop-my-pham-9.jpg" title="Thi công biển quảng cáo shop thời trang – mỹ phẩm " alt="Thi công biển quảng cáo shop thời trang – mỹ phẩm " />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/thi-cong-bien-quang-cao-shop-thoi-trang-–-my-pham">Thi công biển quảng cáo shop thời trang – mỹ phẩm </a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/thi-cong-bien-quang-cao-2" title="Thi công biển quảng cáo "><img src="upload/files/showroom/images.jpg" title="Thi công biển quảng cáo " alt="Thi công biển quảng cáo " />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/thi-cong-bien-quang-cao-2">Thi công biển quảng cáo </a>
            </div>
        </div>
        <div class="itemchay2">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/thiet-ke-va-dung-mat-alu-noi-ngoai-that" title="Thiết kế và dựng mặt alu nội ngoại thất"><img src="upload/files/showroom/bien-quang-cao-mica-3.jpg" title="Thiết kế và dựng mặt alu nội ngoại thất" alt="Thiết kế và dựng mặt alu nội ngoại thất" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/thiet-ke-va-dung-mat-alu-noi-ngoai-that">Thiết kế và dựng mặt alu nội ngoại thất</a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/bien-quang-cao-showroom-2" title="Biển quảng cáo showroom"><img src="upload/files/showroom/bien-hieu-chu-noi-cong-ty-co-phan-Toan-Viet-5_thumb.jpg" title="Biển quảng cáo showroom" alt="Biển quảng cáo showroom" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/bien-quang-cao-showroom-2">Biển quảng cáo showroom</a>
            </div>
        </div>
        <div class="itemchay4">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/thiet-ke-va-thi-cong-quang-cao" title="Thiết kế và thi công quảng cáo "><img src="upload/files/showroom/backdrop-35204_448x320.jpg" title="Thiết kế và thi công quảng cáo " alt="Thiết kế và thi công quảng cáo " />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/thiet-ke-va-thi-cong-quang-cao">Thiết kế và thi công quảng cáo </a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/thiet-ke-noi-that-cua-hang-theo-phong-cach-chuyen-nghiep" title="Thiết kế nội thất cửa hàng theo phong cách chuyên nghiệp"><img src="upload/files/showroom/201012092225_front.jpg" title="Thiết kế nội thất cửa hàng theo phong cách chuyên nghiệp" alt="Thiết kế nội thất cửa hàng theo phong cách chuyên nghiệp" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/thiet-ke-noi-that-cua-hang-theo-phong-cach-chuyen-nghiep">Thiết kế nội thất cửa hàng theo phong cách chuyên nghiệp</a>
            </div>
        </div>
        <div class="itemchay6">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/thiet-ke-thi-cong-shop-cua-hang" title="Thiết kế thi công shop, cửa hàng"><img src="upload/files/showroom/1427590220_untitled-1-jpg.jpg" title="Thiết kế thi công shop, cửa hàng" alt="Thiết kế thi công shop, cửa hàng" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/thiet-ke-thi-cong-shop-cua-hang">Thiết kế thi công shop, cửa hàng</a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/bien-quang-cao-showroom" title="Biển quảng cáo showroom"><img src="upload/files/showroom/1411459583_banghieushopthoitrang7.jpg" title="Biển quảng cáo showroom" alt="Biển quảng cáo showroom" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/bien-quang-cao-showroom">Biển quảng cáo showroom</a>
            </div>
        </div>
        <div class="itemchay8">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/thiet-ke-thi-cong-showroom" title="Thiết kế thi công showroom "><img src="upload/files/showroom/luuy22.jpg" title="Thiết kế thi công showroom " alt="Thiết kế thi công showroom " />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/thiet-ke-thi-cong-showroom">Thiết kế thi công showroom </a>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function () {
            $("#owl-demo18").owlCarousel({
                navigation: true,
                navigationText: ["<", ">"],
                autoPlay: 5000,
                items: 4,
                itemsDesktop: [1199, 3],
                itemsDesktopSmall: [979, 3]
            });

        });
    </script>

    <div class="box_top"><a href="http://quangcaoquanson.com/dich-vu-treo-bang-ron-co-phuon-xin-giay-cap-phep" title="Dịch vụ treo băng rôn, cờ phướn, xin giấy cấp phép">Dịch vụ treo băng rôn, cờ phướn, xin giấy cấp phép</a>
    </div>
    <div id="owl-demo21" class="owl-carousel">
        <div class="itemchay1">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/treo-bang-ron-2" title="Treo băng rôn"><img src="upload/files/bang ron/cờ phướn.jpg" title="Treo băng rôn" alt="Treo băng rôn" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/treo-bang-ron-2">Treo băng rôn</a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/in-bang-ron-dep" title="In băng rôn đẹp"><img src="upload/files/bang ron/bang-ron-vu-lan-5.jpg" title="In băng rôn đẹp" alt="In băng rôn đẹp" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/in-bang-ron-dep">In băng rôn đẹp</a>
            </div>
        </div>
        <div class="itemchay2">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/bang-ron-ngang-bang-ron-doc" title="Băng rôn ngang, băng rôn dọc"><img src="upload/files/bang ron/rol 6 tam.jpg" title="Băng rôn ngang, băng rôn dọc" alt="Băng rôn ngang, băng rôn dọc" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/bang-ron-ngang-bang-ron-doc">Băng rôn ngang, băng rôn dọc</a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/in-bang-ron-quang-cao-2" title="In băng rôn quảng cáo"><img src="upload/files/bang ron/alo_thiet_ke_2.jpg" title="In băng rôn quảng cáo" alt="In băng rôn quảng cáo" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/in-bang-ron-quang-cao-2">In băng rôn quảng cáo</a>
            </div>
        </div>
        <div class="itemchay4">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/in-bang-ron-quang-cao" title="In băng rôn quảng cáo"><img src="upload/files/bang ron/images.jpg" title="In băng rôn quảng cáo" alt="In băng rôn quảng cáo" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/in-bang-ron-quang-cao">In băng rôn quảng cáo</a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/in-an-thi-cong-treo-bang-ron" title="In ấn, thi công treo băng rôn"><img src="upload/files/bang ron/bang_zon_truong_tien_plaza_sua1.jpg" title="In ấn, thi công treo băng rôn" alt="In ấn, thi công treo băng rôn" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/in-an-thi-cong-treo-bang-ron">In ấn, thi công treo băng rôn</a>
            </div>
        </div>
        <div class="itemchay6">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/lap-du-an-treo-bang-ron" title="Lập dự án treo băng rôn"><img src="upload/files/bang ron/treo-bang-ron.jpg" title="Lập dự án treo băng rôn" alt="Lập dự án treo băng rôn" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/lap-du-an-treo-bang-ron">Lập dự án treo băng rôn</a>
            </div>
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/xin-giay-phep-treo-banner" title="Xin giấy phép treo banner"><img src="upload/files/bang ron/treo-bang-ron-hoi-an2.jpg" title="Xin giấy phép treo banner" alt="Xin giấy phép treo banner" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/xin-giay-phep-treo-banner">Xin giấy phép treo banner</a>
            </div>
        </div>
        <div class="itemchay8">
            <div class="item">
                <div class="box_img">
                    <a href="http://quangcaoquanson.com/treo-bang-ron" title="Treo băng rôn"><img src="upload/files/bang ron/bang hieu, in co gia re, in tren vai, in vai tet 2015-2.jpg" title="Treo băng rôn" alt="Treo băng rôn" />
                    </a>
                </div>
                <a class="box_name" href="http://quangcaoquanson.com/treo-bang-ron">Treo băng rôn</a>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function () {
            $("#owl-demo21").owlCarousel({
                navigation: true,
                navigationText: ["<", ">"],
                autoPlay: 5000,
                items: 4,
                itemsDesktop: [1199, 3],
                itemsDesktopSmall: [979, 3]
            });

        });
    </script>


    <div class="box_top"><a href="#">Đối tác</a> </div>
    <div id="owl-demo1" class="owl-carousel">
        <div class="item">
            <div class="box_img">
                <a href="#" title="Đối tác 1"><img src="upload/files/thiết kế logo/Logo1475598594.jpg" title="Đối tác 1" alt="Đối tác 1" />
                </a>
            </div>
            <a class="box_name" href="#">Đối tác 1</a>
        </div>
        <div class="item">
            <div class="box_img">
                <a href="#" title="Đối tác 2"><img src="upload/files/thiết kế logo/images.jpg" title="Đối tác 2" alt="Đối tác 2" />
                </a>
            </div>
            <a class="box_name" href="#">Đối tác 2</a>
        </div>
        <div class="item">
            <div class="box_img">
                <a href="#" title="Đối tác 5"><img src="upload/files/lam bien quang cao/Bien inox mica trong.jpg" title="Đối tác 5" alt="Đối tác 5" />
                </a>
            </div>
            <a class="box_name" href="#">Đối tác 5</a>
        </div>
        <div class="item">
            <div class="box_img">
                <a href="#" title="Đối tác 6"><img src="upload/files/doitac/doitac2.png" title="Đối tác 6" alt="Đối tác 6" />
                </a>
            </div>
            <a class="box_name" href="#">Đối tác 6</a>
        </div>
        <div class="item">
            <div class="box_img">
                <a href="#" title="Đối tác 7"><img src="upload/files/doitac/doitac1.jpg" title="Đối tác 7" alt="Đối tác 7" />
                </a>
            </div>
            <a class="box_name" href="#">Đối tác 7</a>
        </div>
    </div>
    <script>
        $(document).ready(function () {
            $("#owl-demo1").owlCarousel({
                navigation: true,
                navigationText: ["<", ">"],
                autoPlay: 5000,
                items: 4,
                itemsDesktop: [1199, 3],
                itemsDesktopSmall: [979, 3]
            });
        });
    </script>
</div>


<?php get_footer(); ?>