<?php

define('PAGE_DAILY', 27);
define('PAGE_FAQ', 31);
define('PAGE_SUPPORT', 29);
define('PAGE_HOME', 4);
define('PAGE_ABOUTUS', 33);
define('PAGE_FACEBOOK', 61);
define('PAGE_CONTACT', 65);

define('CAT_NEWS', 1);

define('NO_IMAGE', '/img/noimagefound.jpg');